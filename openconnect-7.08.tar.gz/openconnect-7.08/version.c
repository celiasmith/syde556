const char *openconnect_version_str = "v7.08";
